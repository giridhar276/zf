


for val in range(1,10):
    print("*" * val)