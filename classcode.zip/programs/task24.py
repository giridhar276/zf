
import os
import shutil

try:
    source = 'D:\\trainings\\zf\\programs\\source\\'
    destination = 'D:\\trainings\\zf\programs\\destination\\'
    
    
    for file in os.listdir(source):
        shutil.copy(source + file,destination)
        print(source + file ,"copied to ",destination)
except Exception as err:
    print(err)
