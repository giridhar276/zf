

# writing numbers to the file
fobj = open('data.txt','w')
for val in range(1,10):
    fobj.write(str(val) + "\n")
fobj.close()


# context manager
# if any line starts with keyword with..we call it as context manager
# file gets closed automatically when it moves out of indentation
with open('data.txt','w') as fw:
    for val in range(1,10):
        fw.write(str(val) + "\n")












