import subprocess
# Define the command to run the other Python script
command = ["python", "setmethods.py"]
#command = ["bash", "abc.sh"]
# Run the subprocess
process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
# Wait for the subprocess to finish
stdout, stderr = process.communicate()
# Check the return code to see if the subprocess was successful
return_code = process.returncode
# Print the output 
# str.decode() is used to convert bytes to string
print("Standard Output:")
print(stdout.decode())

# Check the return code
if return_code == 0:
    print("Subprocess completed successfully.")
else:
    print(f"Subprocess failed with return code {return_code}.")
