# list
alist = [10,20,30]
alist[0] = 100
print(alist)

# tuple
atup = (10,20,30)
#atup[0] = 100
print(atup)

#typecasting - converting from one object to another object
alist = list(atup)  #step1: convert to the list
alist.append(40)    #step2: make required changes
atup = tuple(alist) #step3: converting back to tuple
print(atup)
