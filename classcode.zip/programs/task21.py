
import os
import sys
import platform
import datetime
import time
try:
    cwd = os.getcwd()
    print("Current working directory :",cwd)
    print("Login name :",os.getlogin())
    print("process id :",os.getpid())
    print("python version :",sys.version)
    print("python version :",sys.version_info)
    print(platform.python_version())
    print(sys.modules)
    print("--------------------")
    print(os.environ)
    print("--------------------")
    print(os.name)
    print(platform.platform())
    print(datetime.datetime.now())
    print(datetime.date.today())
    # display stats of file
    print(os.stat('adult.csv'))
    print("file size :",os.stat('adult.csv').st_size)
    print("file size :",os.path.getsize('adult.csv'),"bytes")
    filename = time.strftime("%d_%b_%Y.csv")
    fobj =  open(filename,"w")
    fobj.close()
    
    
except Exception as err:
    print(err)