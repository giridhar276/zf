
# keyword arguments

def display(b,a,c):
    print(a,b,c)

display(c =30,a = 10 , b = 20)




## example
#sep and end are the keywords already defined
print(10,20,sep= "--",end="\n\n")
print(30)