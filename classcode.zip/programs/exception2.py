
import csv
try:
    filename = input('Enter any filename :')
    with open(filename) as fobj:
        data = csv.reader(fobj)
        for line in data:
            print("Workclass :",line[1])

except Exception as err:
    print(err)    
    print("some unknown error found")