


import getpass
username = input("Enter username :")
password = getpass.getpass()
print(password)
