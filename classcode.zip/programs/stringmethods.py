
name = 'python programming'
print(name)
print("I love",name)
print('python programming')

#this line is commented - single line comment

'''
name = 'python programming'
print(name)
'''

# string[start:stop:incremental]
name = 'python programming'
print(name[0]) #p
print(name[1]) #q
print(name[0:9])
print(name[3:5])
print(name[0:18])
print(name[0:18:1])
print(name[0:18:2])
print(name[1:18:1])
print(name[1:18:2])
print(name[:])  #python programming
print(name[::]) #python programming
print(name[-1])
print(name[-2])
print(name[-4:-1])
print(name[::-1]) # reverse the string




name = 'python programming'
print(name.capitalize())
print(name.lower())
print(name.upper())
print(name)
print(name.center(40))
print(name.center(40,"*"))
print(name.count('p'))
print(name.count('ram'))
print(name.endswith('g'))
print(name.endswith('z'))
print(name.find('prog')) # if found, it returns the starting index
print(name.find('perl')) # if not found, it returns -1

aname  = "I love {} and {}"
print(aname.format('python','unix'))
print(aname.format('c','c++'))

print(name.isupper())
print(name.islower())
print(name.isdigit())
print(name.split(" "))
print(name.replace("python","scala"))
#name = name.replace('python',"scala")
aname = '  python '
print(len(aname))
print(len(aname.strip()))
print(len(aname.lstrip()))
print(len(aname.rstrip()))

# utf-8  format contains 0-65535
print(name.encode('utf-8')) # default
print(name.encode('utf-16'))
print(name.encode('utf-32'))








print(name.isupper())

############ simple if ###########
if name.isupper():
    print("string is upper")
    print("inside if")

##############if-else #############
if name.isupper():
    print("string is upper")
else:
    print("string is lower")

######## if-elif-elif-elif-else ######
name = input('Enter any color:')
if name == 'red':
    print('its red')
elif name == 'green':
    print('its green')
elif name =='blue':
    print('its blue')
else:
    print('its some other color')



# range(start,stop,step)
for val in range(1,11):
    print(val)

for val in range(2,12,2):
    print(val)

for val in range(10,0,-2):
    print(val)


name = 'python'
for char in name:
    print(char)

alist =[10,20,30]
for val in alist:
    print(val)
    
book = {"chap1":10 ,"chap2":20}
for key in book:
    print("key  :",key)  # will display the key only
    print("value:",book[key])





























