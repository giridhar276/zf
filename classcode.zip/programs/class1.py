

class Employee:
    def displayOutput(self):
        print("Employee name :","rita")
    def displayCity(self):
        print("Employee city :","mumbai")
    def displayGender(self):
        print("Employee gender:","F")
        
# object instantiation  or object creation
emp1 = Employee()
emp1.displayOutput()
emp1.displayCity()
emp1.displayGender()