### default arguments
# function body
def display(a = 0 ,b = 0, c = 0):
    print(a,b,c)
#function call
display()
display(10)
display(10,20)
display(10,20,30)

#### examples ###
name = ' python '
print(name.strip())
name = 'python'
print(name.strip('n'))
print(list(range(5)))
print(list(range(2,5)))
print(list(range(2,5,1)))
