############ reading the file line by line
# fr is treated as file cursor or file pointer or file hanlder
with open('languages.txt','r') as fr:
    for line in fr:
        print(line.strip())
        
##### obj.readlines() ##############
with open('languages.txt','r') as fr:
    print(fr.readlines())
    
#### fobj.read() ########  will return the single string
#### not generally suggested to read larger files
with open('languages.txt','r') as fr:
    print(fr.read())
    
## using csv library
## each line gets converted to the list
import csv
with open('languages.txt','r') as fr:
    # convert file object to the csv object
    reader = csv.reader(fr)
    for line in reader:
        print(line)