


import csv
male = 0
female = 0
with open('adult.csv','r') as fr , open('adultinfo_US.csv','w') as fw:
    for line in fr:
        line = line.replace('United-States','USA')
        fw.write(line)