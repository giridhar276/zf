import csv
import os
class File:
    def __init__(self,filename):
        self.filename = filename
    def displayContent(self):
        if os.path.isfile(self.filename) and os.path.getsize(self.filename) > 0:
            with open(self.filename,'r') as self.fobj:
                #converting file object to the csv object
                self.reader = csv.reader(self.fobj)
                for line in self.reader:
                    print(line)

#1st object
file1 = File('adult.csv')
file1.displayContent()
#2nd object
file2 = File('business.csv')
file2.displayContent()


