
import requests
from bs4 import BeautifulSoup

url = 'https://www.google.com/'

response = requests.get(url,verify = False)

if response.status_code == 200:
    print("successful")
    #will dsiplay the html page
    #print(response.text)
    soup = BeautifulSoup(response.text, 'html.parser')
    for link in soup.find_all('a'):
        print(link.get('href'))
        print("----------------")
else:
    print("page not found")

