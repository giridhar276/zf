

#write a program to read adult.csv aand display distinct workclasses
import csv
workset = set()
with open('adult.csv') as fobj:
    data = csv.reader(fobj)
    # processing the data
    for line in data:
        workset.add(line[1])
    # displaying the output
    for work in workset:
        print(work.strip())



worklist = []
with open('adult.csv') as fobj:
    data = csv.reader(fobj)
    # processing the data
    for line in data:
        worklist.append(line[1])
    # displaying the output
    for work in set(worklist):
        print(work.strip())



workdict = dict()
with open('adult.csv') as fobj:
    data = csv.reader(fobj)
    # processing the data
    for line in data:
        workdict[line[1]] = 1
    # displaying the output
    for work in workdict.keys():
        print(work.strip())

{' State-gov':1 , 'Private':1 ,' Self-emp-not-inc':1}