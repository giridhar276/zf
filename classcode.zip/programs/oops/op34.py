

# optional condition
# this condition will be always True
if __name__ == "__main__":
    alist = [10,20,30]
    print(alist)