






import getpass
password = getpass.getpass()
print(password)
