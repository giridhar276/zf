class Student:
    'Common base class for all student'
    studentCount = 0
    def __init__(self,name,fee,age):
        self.name = name
        self.fee = fee
        self.age = age
        Student.studentCount += 1

    def displayCount(self):
        print("Total Students %d" % Student.studentCount )

    def displayStudent(self):
        print("Name : ", self.name , ", Fee : ", self.fee)

    def displayAge(self):
        print("Name : ", self.name , ",Age: ", self.age )

student1 = Student("Ebby",2500,17)
student1.displayStudent()
student1.displayAge()

student2 = Student("Ram",4500,30)
student2.displayStudent()
student2.displayAge()