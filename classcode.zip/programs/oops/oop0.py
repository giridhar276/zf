


alist = [10,20,30]
print(alist)