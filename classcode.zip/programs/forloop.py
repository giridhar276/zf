name = 'python'   # iterating the string
for char in name :
    print(char)
    
    
alist = [10,20,30,40]  # iterating the list
for val in alist:
    print(val)
    
book = {"chap1":10 ,"chap2":20}    # iterating the dictionary
for key in book:
    print(key)
    
for key in book.keys():
    print(key)
    
for value in book.values():
    print(value)
    
for k,v in book.items():
    print("key :",k)
    print("value :",v)
    
    
aset = {10,20,20,30,30,30}  # iterating the set
for val in aset:
    print(val)





    