# writing some lines to the file
fobj = open('output.txt','w')
fobj.write('python programming\n')
fobj.write('unix shell\n')
fobj.close()



# writing numbers to the file
fobj = open('numbers.txt','w')
for val in range(1,10):
    fobj.write(str(val) + "\n")
fobj.close()


# writing numbers to the file
fobj = open('D:\\trainings\\zf\\numbers1.txt','w')    # method1
for val in range(1,10):
    fobj.write(str(val) + "\n")
fobj.close()


# writing numbers to the file
fobj = open('D:/trainings/zf/numbers2.txt','w')      # method2
for val in range(1,10):
    fobj.write(str(val) + "\n")
fobj.close()

# writing numbers to the file
fobj = open(r'D:\trainings\zf\numbers3.txt','w')    # method3  # rawstring
for val in range(1,10):
    fobj.write(str(val) + "\n")
fobj.close()










