
class Employee:
    def getInfo(self,name):
        #local variable
        self.name = name
    def displayInfo(self):
        print("Employee name :",self.name)
        
emp1 = Employee()
emp1.getInfo('rita')
emp1.displayInfo()

emp2 = Employee()
emp2.getInfo('gita')
emp2.displayInfo()

emp3 = Employee()
emp3.getInfo('Ram')
emp3.displayInfo()