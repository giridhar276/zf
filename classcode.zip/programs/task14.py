



import csv
male = 0
female = 0
with open('adult.csv') as fobj:
    for line in fobj:
        print(line.lower())