
import csv
male = 0
female = 0
with open('adult.csv') as fobj:
    data = csv.reader(fobj)
    # processing the data
    for line in data:
        gender = line[9].strip()
        if gender == 'Male':
            male+=1
        elif gender == 'Female':
            female+=1

print("Total male count :",male)
print("Total female count:",female)
        