book = {"chap1":10 ,'chap2':20,'chap3':30}
print(book)

book = {"chap1":10 ,'chap2':20,'chap3':30,'chap1':100}
print(book)
# create new key-value pairs
book['chap4'] = 40
book['chap5'] = 50
print(book)

#display individual values
print(book['chap1']) # 100
print(book['chap2']) # 20

# display dictionary keys
print(book.keys())
# display dictionary values
print(book.values())
# display dictionary items
print(book.items())  # list of tuples
# remove key-value pair
book.pop('chap1') # chap1-100 will be removed from dict
print(book)
book.popitem()  # will remove the last key-value 
book.popitem()
print(book)

newbook = {"chap5":50 ,"chap6":60,"chap7":70}
finalbook = {**book,**newbook}
print(finalbook)


book.update(newbook) # newbook is updated to book
print(book)













