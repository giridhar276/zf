

import csv
genres = set()
with open('movies.csv','r',encoding='utf-8') as fobj:
    data = csv.reader(fobj)
    for line in data:
        genre = line[2].split("|")
        for element in genre:
            genres.add(element)

print("GENRES")
print("-------")
for item in genres:
    print(item)