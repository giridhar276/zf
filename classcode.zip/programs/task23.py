####### display files ONLY
import os
try:
    files = os.listdir()
    for file in files:
        if os.path.isfile(file):
            print(file)
except Exception as err:
    print(err)
    
####### display files ONLY ################
import os
try:
    files = os.listdir()
    for file in files:
        if os.path.isdir(file):
            print(file)
except Exception as err:
    print(err)
    
######### display file and its size ############
import os
try:
    files = os.listdir()
    for file in files:
        if os.path.isfile(file):
            print(file.ljust(20), os.path.getsize(file),"bytes")
except Exception as err:
    print(err)    