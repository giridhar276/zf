import psutil
import datetime
print("-------------")
print(psutil.cpu_percent())
print("-------------")
print(psutil.virtual_memory())
print("-------------")
print(psutil.swap_memory())
print("-------------")
print(psutil.disk_partitions())
print("-------------")
print(psutil.disk_usage("C:\\"))
print("-------------")
print(psutil.disk_usage("D:\\"))
# dipplay the rebooted time
time = psutil.boot_time()
print(time)
output = datetime.datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")
print(output)
# users logged in
print(psutil.users())
# display all the process ids
print(psutil.pids())