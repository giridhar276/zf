


import pwinput
username = input("Enter username :")
password = pwinput.pwinput(prompt='Enter password :',mask='*')
print(username)
print(password)