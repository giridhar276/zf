import csv
male = 0
female = 0
with open('adult111111.csv','r') as fr , open('adultinfo_US.csv','w') as fw:
    for line in fr:
        line = line.replace('United-States','USA')
        fw.write(line)