#  + operator
print(3 + 5)
print("python" + "programming")
print([10,20] + [30,40])
print((30,40) + (40,50))

# *
name = 'python'
print(name * 5)
alist = [10,20,30,30]
print(alist * 4)

if 'ram' in name :
    print('substring exists')
    
alist = [10,20,30,40]
if 20 in alist:
    print('value exists')
        
book = {'chap1':10 ,"chap2":20}
if 'chap1' in book:
    print("key exists")
    
    
    
    
    
    

