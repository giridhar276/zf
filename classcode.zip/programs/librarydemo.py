
#method1 : 
#all the methods will be imported will be imported to the program
import math
print(math.log(1))
print(math.tan(2))


#method2
import math  as m
print(m.floor(243.3))
print(m.ceil(23.2))

import matplotlib.pyplot as plt
plt.plot([10,20],[30,40])

# method3 : importing the required methods ONLY
from math import log,cos
print(log(1))
print(cos(2))