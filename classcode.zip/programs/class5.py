

import fileread


file= fileread.File('adult.csv')
file.displayContent()