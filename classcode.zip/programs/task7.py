lang  = ["spark","spark","spark","java","unix","unix","python","python"]




for val in set(lang):
    print(val , lang.count(val),"times")