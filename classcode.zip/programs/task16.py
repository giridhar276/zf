


import csv
with open('supermarket_sales.csv') as fobj:
    data = csv.reader(fobj)
    for line in data:
        if line[2] == 'Yangon'   and line[3] == 'Normal' and line[12] == 'Cash' and line[4] =='Female' :
            print(line)