


import csv
with open('adult.csv') as fobj:
    data = csv.reader(fobj)
    for line in data:
        print("Workclass :",line[1])
        print('Eduation  :',line[6])
        print("---------")
    