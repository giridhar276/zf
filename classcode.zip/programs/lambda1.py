# tradional way 
def display(a,b):
    c = a + b
    return c

#function call
total = display(10,20)
print(total)

#pythonic way
#lambda function  # inline function  # nameless func
# lambda is the replacement of single line function
# lamba function is faster compared to regular function block
#syntax:    functioname = lambda variables:expression
display= lambda a,b : a + b
total = display(10,20)
print(total)


display= lambda *args : sum(args)
total = display(10,20,30,40,50,60,70,70,10,20)
print(total)

square = lambda x : x *x if x >0  else 'not possible'
print(square(3))
print(square(0))
print(square(1))


alist = ["google","unix","java"]
#Ouptput: ["www.google.com","www.unix.com","www.java".com"]
blist =[]
for val in alist:
    blist.append("www." + val + ".com")
print(blist)
# method2
string = "www.{}.com"
for val in alist:
    print(string.format(val))

# method3
def modify(x):
    return "www." + x + ".com"
#map(function,iterable)
print(list(map(modify,alist)))

# method4
#map(function,iterable)
print(list(map(lambda x:"www." + x + ".com",alist)))

alist = [12,3,4,5,3,6,7,10]
print(list(filter(lambda x :x%2==0,alist)))#even numbrs
print(list(filter(lambda x :x%2,alist))) # odd numbers

data = ['unix','java','oracle','ruby','python']
#output ['unix','java','ruby']
print(list(filter(lambda x :len(x)==4,data)))



























