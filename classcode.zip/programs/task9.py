


filename = input("Enter file name :")

if filename.endswith('.py'):
    print('its python file')
elif filename.endswith('.sh'):
    print('its shell file')