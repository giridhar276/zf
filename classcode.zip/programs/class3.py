class Employee:
    #constructor is invoked automatically
    #constructor in python begins with __init__
    def __init__(self,name,age,address):
        #local variable
        self.name = name
        self.age = age
        self.address = address
        
    def displayInfo(self):
        print("Employee name    :",self.name)
        print("Employee age     :",self.age)
        print("Employee address :",self.address)
  
        
emp1 = Employee('rita',23,'Hyderabad')
emp1.displayInfo()


emp2 = Employee('gita',26,'mumbai')
emp2.displayInfo()

emp3 = Employee('Ram',30,'Delhi')
emp3.displayInfo()