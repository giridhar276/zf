

#### fixed arguments

# function body
def display(a,b):
    c = a + b
    return c


#function call
total = display(10,20)
print(total)